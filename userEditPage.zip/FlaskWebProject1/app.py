from flask import Flask, render_template, request

app = Flask(__name__)

def writepagecontent(content):
    with open("pagecontent.txt", "w") as file:
        file.write(content)

def read_page_content():
    try:
        with open("page_content.txt", "r") as file:
            return file.read()
    except FileNotFoundError:
        return ""

@app.route('/')
def index():
    content = read_page_content()
    return render_template('index.html', content=content)

@app.route('/edit', methods=['GET', 'POST'])
def edit():
    if request.method == 'POST':
        content = request.form['content']
        writepagecontent(content)  # Update this line to match the function name
        return render_template('edit.html', message='Page updated successfully!')
    else:
        content = read_page_content()
        return render_template('edit.html', content=content)


if __name__ == '__main':
    app.run(debug=True)
