from FlaskWebProject1.app import app  # Import the app instance from app.py in FlaskWebProject1 package

if __name__ == '__main__':
    app.run(debug=True)
